# OpenWeather API test

Postman collection to test max temp of a city against predefined temperature.
    Set the variables to test a certain city, by default it tests New York
    the `BaseUrl` variable allow us to test different environments, for instance staging and production.

### Run the collection using Postman UI
Simply import the collection `OpenWeather.postman_collection.json` and the environment variables `OpenWeather.prod.postman_environment.json` and run it from UI.
### Run the collection using the CLI

`newman run OpenWeather.postman_collection.json -e OpenWeather.prod.postman_environment.json`
    Make sure you have newman installed, if not please install it by running this `npm install -g newman`

### Notes 
To get the forecast for tomorrow we need a paid account apparently, the only API that worked with the free subscription is current data API.