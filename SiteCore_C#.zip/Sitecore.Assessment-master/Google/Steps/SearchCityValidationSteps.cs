﻿using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using Xunit;
using OpenQA.Selenium.Support.UI;

namespace Google.Steps
{
    [Binding]
    public class SearchCityValidationSteps
    {
        private readonly IWebDriver _webDriver;
        IWebElement searchText;
        private string resultText;

        public SearchCityValidationSteps(ScenarioContext scenarioContext)
        {
            _webDriver = scenarioContext["WEB_DRIVER"] as IWebDriver;
        }

        [Given(@"I have navigated to the Google home page")]
        public void GivenIHaveNavigatedToTheGoogleHomePage()
        {
            _webDriver.Url = $"https://www.google.com";
            CloseCookiesPopup();
        }

        private void CloseCookiesPopup()
        {
            try
            {
                var wait = new WebDriverWait(_webDriver, TimeSpan.FromSeconds(5));
                wait.Until(drv => drv.FindElement(By.Id("cnsw")));
                _webDriver.SwitchTo().Frame(0);
                var agreeButton = _webDriver.FindElement(By.Id("introAgreeButton"));
                agreeButton.Click();
            }
            catch (Exception)
            {
                // Maybe I can find a better way to handle cases when popup is not present 
            }
            finally
            {
                _webDriver.SwitchTo().DefaultContent();
            }
        }

        [Given(@"The Search term is (.*)")]
        public void GivenTheSearchTermIs(string city)
        {
            searchText = _webDriver.FindElement(By.Name("q"));
            searchText.SendKeys(city);
        }

        [When(@"Hit search")]
        public void WhenHitSearch()
        {
            searchText.SendKeys(Keys.Enter);
        }

        [Then(@"A result page Contains (.*) is shown")]
        public void ThenAResultPageContainsIsShown(string city)
        {
            var resultPanel = _webDriver.FindElement(By.XPath("//h2/span[1]"));
            resultText = resultPanel.Text;
            Assert.Contains(city, resultPanel.Text);
        }


        [AfterScenario]
        public void TakeScreenshot()
        {
            Screenshot ss = ((ITakesScreenshot)_webDriver).GetScreenshot();
            // Output folder should not be hardcoded !
            ss.SaveAsFile($"C:\\Work\\output\\{resultText}-screenshot-{DateTime.Now.ToString("ddMMyyyhhmmss")}.png", ScreenshotImageFormat.Png);
        }
    }
}
