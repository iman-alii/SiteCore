﻿using System.Text;

namespace Expidia.Hooks
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Firefox;
    using TechTalk.SpecFlow;

    namespace SpecFlowUiAutomation
    {
        [Binding]
        public class TestHooks
        {
            [Before]
            public void CreateWebDriver(ScenarioContext context)
            {
                CodePagesEncodingProvider.Instance.GetEncoding(437);
                Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

                var options = new FirefoxOptions();
                //options.AddArgument("-headless"); 
                var profile = new FirefoxProfile();
                profile.SetPreference("intl.accept_languages", "en-US");
                options.Profile = profile;
                IWebDriver webDriver = new FirefoxDriver(options);
                context["WEB_DRIVER"] = webDriver;
            }

            [After]
            public void CloseWebDriver(ScenarioContext context)
            {
                var driver = context["WEB_DRIVER"] as IWebDriver; 
                driver.Quit();
            } 
        }
    }
}
