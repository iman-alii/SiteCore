﻿using FluentAssertions;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Linq;
using TechTalk.SpecFlow;

namespace Expedia.Steps
{
    [Binding]
    public class PackageSearchSteps
    {
        private readonly IWebDriver _webDriver;

        public PackageSearchSteps(ScenarioContext scenarioContext)
        {
            _webDriver = scenarioContext["WEB_DRIVER"] as IWebDriver;
        }

        [Given(@"The Packages view in the US Expedia website")]
        public void GivenUSExpediaWebsite()
        {
            _webDriver.Url = $"https://www.expedia.com/?siteid=1&pwaLob=wizard-package-pwa";
        }


        [Given(@"Source is (.*)")]
        public void GivenSourceIs(string source)
        {
            var sourceInputParent = _webDriver.FindElement(By.Id(@"location-field-origin-menu"));
            var sourceInput = sourceInputParent.FindElement(By.ClassName(@"uitk-faux-input"));
            sourceInput.SendKeys(Keys.Space + source + Keys.Enter);
        }

        [Given(@"destination is (.*)")]
        public void GivenDestinationIs(string destination)
        {
            var destinationInputParent = _webDriver.FindElement(By.Id(@"location-field-destination-menu"));
            var destinationInput = destinationInputParent.FindElement(By.ClassName(@"uitk-faux-input"));
            destinationInput.SendKeys(Keys.Space + destination + Keys.Enter);
        }

        [Given(@"travel day is after (.*) days")]
        public void GivenTravelDayIsAfterDays(int days)
        {
            // for simplicity we book a trip within 2 month, longer trips will require scrolling through the datetime picker  
            var checkinDate = DateTime.Now.AddDays(days);
            var checkoutDate = checkinDate.AddDays(7);


            var checkinDatePicker = _webDriver.FindElement(By.Id(@"d1-btn"));
            checkinDatePicker.Click();

            SelectDayofMonth(checkinDate);
            SelectDayofMonth(checkoutDate);
        } 

        private void SelectDayofMonth(DateTime checkinDate)
        {
            var checkInDateButton = _webDriver.FindElement(By.XPath(@$"//button[@aria-label='{checkinDate.ToString("MMM d, yyyy")}']"));
            checkInDateButton.Click();
        }

        [Given(@"number of adults is (.*)")]
        public void GivenNumberOfAdultsIs(int adutls)
        {
            if (adutls <= 0)
                throw new ArgumentOutOfRangeException(nameof(adutls), "invalid test data, number of adutl travelers can not be less than 1");

            var travelersLink = _webDriver.FindElement(By.XPath(@"//a[@data-testid='travelers-field']"));
            travelersLink.Click();
            var wait = new WebDriverWait(_webDriver, TimeSpan.FromSeconds(2));
            wait.Until(drv => drv.FindElement(By.XPath(@"//*[@data-testid='guests-done-button']")));
            if (adutls > 2) // click button if passed number is not equal to the default(2)
            {
                // here we can write some logic to set the correct number 
                // as adults is bigger than 2 , we will write logic to click the (+) button number of times to meet the request.
                // for instance if the passed adults=4.. then we need to click the button 2 times, that could be done using a for loop
            }
            else if (adutls < 2)
            {
                // here we click the  (-) button once
            }
        }

        [Given(@"age of the child is (.*)")]
        public void GivenAgeOfTheChildIs(int childAge)
        {
            if (childAge < 2 || childAge > 17)
                throw new ArgumentOutOfRangeException(nameof(childAge), "invalid test data, child age should be between 2 and 17");

            var numberofChildrenPanel = _webDriver.FindElement(By.XPath(@"//div[2]/div[@class='uitk-flex uitk-flex-item uitk-step-input-controls' and 1]"));
            var increaseNumberOfChildernButton = numberofChildrenPanel.FindElements(By.TagName("Button"))[1];
            increaseNumberOfChildernButton.Click();

            var childAgeControl = _webDriver.FindElement(By.XPath(@"//select[@id='child-age-input-0-0']"));

            childAgeControl.SendKeys(Keys.Enter + childAge + Keys.Enter); 
        }

        [When(@"hit the search button")]
        public void WhenHitTheSearchButton()
        {
            var searchForm = _webDriver.FindElement(By.Id("wizard-package-pwa-1"));
            searchForm.Submit();
        }

        [Then(@"the result page contains travel option for the chosen (.*)")]
        public void ThenTheResultPageContainsTravelOptionForTheChosen(string destinationFull)
        {
            var wait = new WebDriverWait(_webDriver, TimeSpan.FromSeconds(20));
            wait.Until(drv => drv.FindElement(By.XPath(@"//main[@class='search-results__main s-x-margin-two']")));
            var results = _webDriver.FindElements(By.XPath(@"//*[@data-test-id='content-hotel-neighborhood']"));
            var resultsTexts = results.Select(r => r.Text.ToLower()).ToList(); 
            resultsTexts.Should().Contain(destinationFull.ToLower());
        }
    }
}
